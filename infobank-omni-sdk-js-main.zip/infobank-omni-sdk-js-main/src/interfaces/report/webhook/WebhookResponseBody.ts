

/**
 * Interface: WebhookResponse
 * Description: webhook 응답
 */
export interface WebhookResponseBody {
  /** 메시지 키 */
  msgKey: string;
}

